# Setting up SSL using zdp-ansible
Setting up SSL can be a challenge, I agree, and because of that we created this guide 
that will help you setup it up with ease for your Arena Services.

### SSL setup using self signed certificates
By default, zdp-ansible has built-in support to generate certificates, keys, keystore and a truststore
for each of your nodes, be it a single node setup or a multi-node setup. The catch here is
that these certificates are self signed i.e. no external CA or certificate authority has 
been used to sign these certificates. CA signed certificates are more secure that self signed
certificates, so if you have a external CA, it would be better to generate the certificates manually
and sign them using the CA, and follow the section **SSL setup using CA signed certificates**.

So, setting up SSL using self signed certificates is fairly easy, and all we need to do is set
a couple of properties in the `inventory/<inventory-name>/group_vars/all/vars.yml`, and listed below 
are the properties that we need to take care of.

1. `generate_certs`: Set this to `True`. This property ensures that zdp-ansible is the one who will be
generating certificates. If this is set to false, certificates will not be generated.
2. `tls_ca_external`: Set this to `False`, since we are going to generate certificates without an 
external CA.
3. `enable_zdp_tls`: Set this to `True`. This is a must have since this property controls whether we 
are setting up SSL or not.

After setting up these properties, run the `zdp-installer-playbook.yml` and Arena services will be 
setup with SSL.

**Note:** While using ansible to generate certificates, it is recommended to use hostnames instead of
ip address in the hosts.yml file.

### SSL setup using CA signed certificates

When using an external CA, ansible won't be generating the certificate, keystore or truststore. So 
the user needs to create these manually. He will also need to setup the keystore and the truststore
and also add the certificates to it for each node. After this is done, we can proceed forward with
making the required changes in zdp-ansible. These are the following properties that need to be set 
up or that need to be added/set in `inventory/<inventory-name>/group_vars/all/vars.yml` depending on
your requirement,

1. `generate_certs`: Set this to `False`. Since we are using manually generated certificates, we 
need to set this to false.
2. `enable_zdp_tls`: Set this to `True`.
3. `certs_truststore_name`: By default this property is set to `zdp_truststore.jks`. If you are using
a different name then, add this property in inventory vars.yml and set it to the truststore file name.
4. `certs_truststoretype`: By default this is set to `PKCS12`. If your truststore is of a different type,
add this property in inventory vars.yml and set it accordingly.
5. `certs_truststore_location`: By default this property is set to `/var/zdp-tls`. If your truststore is
in a different location, add this property and set it to the location of the truststore.
6. `certs_privatekey_extension`: By default this is set to `.pxf`. In case you are using a keystore with
a different extension, add this property and set it accordingly.
7. `zdp_tls_ca_location`: Set this property to the exact path of the CA(Certificate Authority) file. Check
the vars.yml file for more details about setting this property. By default, it's value is not set.

After setting up these properties, run the zdp-installer-playbook.yml and Arena services will be setup with SSL.

**Note:** While using a keystore, make sure that it's of type PKCS12. Even though most services are 
JVM based and can use both JKS and PKCS12 type keystore, but since Kibana is a NodeJS process, it can
only use a PKCS12 keystore.

