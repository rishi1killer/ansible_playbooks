# Zaloni Data Platform Ansible playbooks

These are Ansible playbooks that can be used to:

1. Install Arena
2. Start, Stop and check the status of Arena services
3. Upgrade from Arena 5.0.2 and above to Arena 6.0.0

## Verified playbooks for Customer Environments

1. zdp-installer-playbook.yml - installs Arena
2. zdp-start-playbook.yml - starts Arena
3. zdp-status-playbook.yml - print the status of various Arena services
4. zdp-stop-playbook.yml - stop zdp services

## Prerequisites

1. Ensure you have all the Arena prerequisites (see Arena documentation for details)
2. Install [Ansible](https://docs.ansible.com/ansible/2.9/installation_guide/intro_installation.html). These playbook validated against Ansible 2.9.15 with Python 3.6.8
3. Environments such as virtual machines, where enough entropy may not be available, install `rng-tools` via `yum install rng-tools; rngd -r /dev/urandom`
4. Arena Ansible playbooks require root privileges to install RPM and to run `chown`
    * It is strongly reccommended that you do not run these playbooks as root. Instead use a privilege escalation method.
    * Ansible provides the following privilege escalation methods to use (default=sudo), valid choices: [ sudo | su | pbrun | pfexec | doas | dzdo | ksu | runas | machinectl ]
    * These requirements is the same as any ansible playbook that installs RPMs or executes `chown`.

## Advanced scenarios

1. In installation environments where MySQL SYSTEM PRIVILEGES are not granted for the Arena mysql user or DBA, SQL scripts need to be executed should be done before starting Arena services. Contact Zaloni support to access these SQL scripts.

2. When upgrading manually installed Arena deployments with the ansible installer, note that some Arena Mysql tables may have previous been configured with IP addresses, instead of dns names which are configured in Ansible's inventory. These can be fixed with these SQL statements (this needs to be done just once; subsequent upgrades do not modify these tables)

```sql
    -- zdp-executor changes
    UPDATE `WORKFLOW_EXECUTOR_AGENT` SET URL='http:/<zdp-executor HOSTNAME>' WHERE URL='http://<zdp-executor IP ADDRESS>';

    -- zdp-ingestion-warden changes
    UPDATE `DI_LZ_SERVER` SET NAME='<zdp-ingestion-warden HOSTNAME>', IP_ADDRESS='<zdp-ingestion-warden HOSTNAME>', HOST='<zdp-ingestion-warden HOSTNAME>' WHERE IP_ADDRESS='<zdp-ingestion-warden FDNS HOSTNAME>';

    UPDATE DI_MASTER_AGENT SET SERVER_IP='<zdp-ingestion-warden HOSTNAME>' WHERE SERVER_IP='<zdp-ingestion-warden FDNS HOSTNAME>';

    UPDATE FL_SERVERS SET FL_SERVER_NAME='<zdp-ingestion-warden HOSTNAME>', FL_SERVER_IP_ADDRESS='<zdp-ingestion-warden HOSTNAME>' WHERE FL_SERVER_NAME='<zdp-ingestion-warden FDNS HOSTNAME>';

```

4. If using a public DNS name or load balancers for the Arena gateway, the `GATEWAY_URL` system configuration may need to be changed (it defaults to the IP address of the zdp Gateway service). To make the change, log into the Arena gateway UI as admin, and navigate to Adminstration > System Configuration Management

5. In environments where `hive.aux.jars.path` is restricted (such as where Cloudera Sentry is installed), copy the bedrock-hive-hooks, parquet-hive-bundle, bedrock-masking-udf and bedrock-tokenization-udf jars from `BEDROCK_HDFS_LIB_DIR` to `HIVE_AUX_JARS_PATH` on HiveServer2 servers, and then enable HIVE_ACTION_SKIP_ADD_JARS from Adminstration > System Configuration Management. If reload hive aux jars is not configured on the HiveServer2, restart HiveServer2. This needs to be done again when Arena is upgraded, when the versions for the bedrock-hive-hooks, parquet-hive-bundle, bedrock-masking-udf and bedrock-tokenization-udf jars change.

6. For every upgrade, patching, reinstall of zdp software, please ensure to stop zdp services before upgrade and start service after upgrade unless the playbook executed does call the respective start and stop playbooks.

7. File and Stream agents stop, start and restart operations should be done from Arena UI.

8. SSL can be enabled on for zdp-gateway by setting `enable_ssl_only_for_gateway` to `True` and `enable_zdp_tls` to `True`. If `enable_zdp_tls` is `True` and `enable_ssl_only_for_gateway` is `False` then ssl is enabled for all applicable zdp services.

9. If MYSQL setup fails for activemq HA, manually install the RPM package from  https://dev.mysql.com/downloads/connector/j/

## Setting up variables for Arena env

1. Copy ```inventory/example``` to ```inventory/my-cluster```.
In setups where this was already configured, the old vars.yml and vault.yml files can be reused in new playbooks given but need to add and configure any newly introduced variables in the end of the hosts.yml, vault.yml and vars.yml. If any new files are added/updated in inventory, e.g default.yml, those as well need to be updated as per the inventory example received for new playbook.

2. Set the target topology by editing the ```inventory/my-cluster/hosts.yml``` file and make appropriate changes to support Arena multi node and ha deployment. Please check with Z support for Arena multi node and HA deployment queries.

3. Review and edit appropriately, the various variables in ```inventory/my-cluster/group_vars/all/vars.yml```.

4. Review and edit appropriately, the various secret/sensitive values in ```inventory/my-cluster/group_vars/all/vault.yml```.

## Playbooks

The various ```zdp*playbook.yml``` files describe the various actions that you can run on your target hosts.

0. ```zdp-main-playbook.yml``` — Installs all prerequisites (except hadoop), and Arena on your topology.
1. ```zdp-installer-playbook.yml``` — Install Arena on your topology.
2. ```zdp-start-playbook.yml``` — Start Arena on your topology. ~ 10 min
3. ```zdp-prerequisites-playbook.yml``` — Test if all the prerequisites are set up.
4. ```zdp-prerequisites-install-playbook.yml``` — Installs some prerequisites (MySQL, NodeJS, NFS) for Arena.
5. ```zdp-post-configuration-playbook.yml``` — Configures MySQL Server, linux limits and other option tuning parameters for Arena.
6. ```zdp-stop-playbook.yml``` — Stop Arena on your topology. ~ 2 min
7. ```zdp-status-playbook.yml``` — Check status on your topology.  ~ 2 min
8. ```zdp-uninstall-playbook.yml``` — Uninstall Arena on your topology. Removes logs, settings and data.
9. ```zdp-health-playbook.yml``` — Check health of Arena services.

For example zdp-installer-playbook.yml cab be run as:

If password-less ssh and become user are configured

```sh
ansible-playbook zdp-installer-playbook.yml -i inventory/my-cluster
```

If password need to be entered at command line for ssh and become user

```sh
ansible-playbook zdp-installer-playbook.yml -i inventory/my-cluster --ask-pass --ask-become-pass
```

## Installing only some services

Each service is associated with corresponding tags which allow you to install some services. For example you could install only the zdp-mr and zdp-es service:
```
ansible-playbook zdp-install-playbook.yml -i inventory/example --tags "mr,es"
```
There is also a specific tag for for zdp-mr, zdp-spark and zdp-hive called cluster. Therefore instead of:
```
ansible-playbook zdp-install-playbook.yml -i inventory/example --tags "mr,hive,spark"
```
you could use:
```
ansible-playbook zdp-install-playbook.yml -i inventory/example --tags "cluster"
```

And similarly you could install everything EXCEPT dme service like so:
```
ansible-playbook zdp-install-playbook.yml -i inventory/example --skip-tags "dme"
```

## Executing inside Docker Container

1. Build the zdp-ansible image using the following command
    ``` docker build -t zdp-ansible:latest -f ./Dockerfile . ```
1. Create your own inventory in the directory inventory
1. Modify the command ``` docker run -v <path to inventory directory>:/code/inventory zdp-ansible:<tag> "ansible-playbook <playbook name> -i /code/inventory/<inventory-name>"``` to use any of the supported playbooks. 
    1. For eg, Installing zdp-ansible
        ``` docker run -v /home/ec2-user/zdp-ansible/inventory:/code/inventory zdp-ansible:latest "ansible-playbook zdp-install-playbook.yml -i /code/inventory/example" ```

## Contributing Changes

### Roles and Tasks

Each Arena service has its own directory under the ```roles``` directory, along with a common role directory. There are task directories under each role where you can add files relevant to some activity. For example:

1. ```roles/registry/tasks/encrypt.yml``` — Helps encrypt sensitive values using the registry.

2. ```roles/registry/tasks/install.yml``` — Helps install the registry.

## Appendix: Ansible crash course

1. Install ansible using ```brew install ansible``` on OS-X or ```yum install ansible``` on Linux

2. List out all the hosts in your playbook:
```
ansible all -i inventory/hosts.yml --list-hosts
```

3. Run a command ```df -h``` as bbdeka on all the hosts:
```
ansible all -i inventory/hosts.yml -u bbdeka -m command -a "df -h"
```
(If you don't have password-less ssh setup, append the ```--ask-pass``` to this command)

4. Run a command ```df -h``` as sudo on all the hosts:
```
	ansible all -i inventory/hosts.yml  -m command -a "df -h" --ask-pass -become
```
(If sudo requires a password, append the <code>-ask-become-pass</code> to this command)

5. Dry-run a playbook on the hosts:
```
ansible-playbook -C zdp-install-playbook.yml -i inventory/single-node-example --ask-pass
```

6. Running a playbook with debugging enabled:
```
ansible-playbook -vv zdp-installer-playbook.yml -i inventory/example --ask-pass
```

7. Encrypt the vault:
```
ansible-vault encrypt --ask-vault-pass inventory/example/group_vars/all/vault.yml
```

8. Decrypt the vault:
```
ansible-vault decrypt --ask-vault-pass inventory/example/group_vars/all/vault.yml
```

## Advanced Use-Cases

* Use -f option to specify number of parallel processes to use for ansible playbook
```
ansible-playbook -i inventory/prod zdp-stop-playbook.yml -f 10
```

* To comment out a particular service like dme either --skip-tags dme can be used or in hosts.yml following can be done
```
        # dme:
        #   hosts:
        #     edgenode1.zalonilabs.com:
        #     edgenode2.zalonilabs.com:
```

* Add host variables to define ingestion warden group names. For example:
```
         ingestionwarden:
           hosts:
             edgenode1.zalonilabs.com:
               vars:
                 warden_group_name: 'group1'
             edgenode2.zalonilabs.com:
               vars:
                 warden_group_name: 'group2'
```

### Multi-cluster setup

By default, we assume a single cluster setup, which may have multiple zdp cluster services. If you want to setup multi-cluster, edit the inventory like so. For example, here we set up three instances of zdp-mr on three hosts, spread across two clusters:

```yaml
    mr:
      hosts:
        host1:
           vars:
           cluster_id: blue
        host2:
           vars:
           cluster_id: blue
        host3:
           vars:
           cluster_id: green
```

### Setup for nodes with multiple network interfaces

In cases where there are multiple network interfaces attached to a node, the hosts.yml file needs to be setup differently. Since a node has multiple interfaces, the hostname that ansible uses to connect to the nodes, and the hostname that the nodes use to connect to each other is different.

```
...
    zdp:
      children:
        registry:
          hosts:
            jumper:
              ansible_host: 192.0.2.50
              ansible_port: 5555
```

Here, `jumper` is the DNS name that the other nodes in the network will use to connect to this node. And `192.0.2.50` is the address/DNS name ansible will use to ssh into the node.

For further info check: https://docs.ansible.com/ansible/latest/user_guide/intro_inventory.html#inventory-aliases

### Setting up SSL for Arena Services
Check the SECURITY.md file for a detailed walkthrough on how to setup SSL, using both self signed and manually generated certificates.

### Added a new property in mr.yml and spark.yml which should be pointed to the base location for all keytab files for users.This property was introduced as part of the Plugin model supoort for impersonation feature.
```yaml
kerberos.keytabs.base.dir:
```
