# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),

## [Unreleased]

### Changed
- Updated logstash from 6.7.1 to 7.16.1
- updated ExecStart with /opt/zdp/zdp-logstash/bin/logstash in zdp-logstash.service.j2 
- Updated roles/zdp/tasks/logstash/install.yml since zdp-logstash.yml is not used any more.
- Added 'clean_zdp_data_before_install' which replaces 'zdp_upgrade_only' property and when set will clear zdp data before installation.
- Added 'cleanup_zdp_database' which replaces 'clean_zdp_data_after_uninstall' property and when set will clear zdp data during  uninstallation.

### Removed
- deleted roles/zdp/templates/logstash/zdp-logstash.yml.j2 since zdp-logstash.yml is not used any more.

### Added
- Added back configuring OIDC. 
- If the required properties are present in vars and flag `save_oidc_config` is set to true, configuration will be saved.
- If the flag `activate_oidc` is set to true, OIDC config will be activated.
- OIDC URIs are required but in case of okta/keycloak can be skipped if `okta_auth_server` or `keycloak_realm_name` are provided.
- Added `eureka.client.ssl.certificate-validation` property in kibana.yml and `NODE_EXTRA_CA_CERTS` in zdp-kibana.conf to validate ssl cert while kibana service communicating with registry 
### Renamed
- In zdp-gateway.yml.j2 property name `spring.datasource.hikari.maxPoolSize` is changed to `spring.datasource.hikari.maximumPoolSize

## [6.6.3]

### Changed
- Replaced `server.ssl.certificate` and `server.ssl.key` with `server.ssl.keystore.path` in kibana.yml.j2
- Moved `zdp_es_cert_location_on_target_server` from roles/zdp/vars/main.yml to roles/zdp/default/main.yml

### Added
- Following xpack.security properties added to elasticsearch.yml.j2
    - `xpack.security.transport.ssl.keystore.path`
    - `xpack.security.transport.ssl.keystore.password`
    - `xpack.security.transport.ssl.keystore.type`
    - `xpack.security.transport.ssl.truststore.path`
    - `xpack.security.transport.ssl.truststore.password`
    - `xpack.security.http.ssl.keystore.path`
    - `xpack.security.http.ssl.keystore.password`
    - `xpack.security.http.ssl.keystore.type`
    - `xpack.security.http.ssl.truststore.path`
    - `xpack.security.http.ssl.truststore.password`
- New property `zdp_tls_ca_location` in vars.yml. Used to set the CA location in kibana.yml.j2.
- Added new `SECURITY.md` file, which contains a detailed walkthrough for setting up SSL on Arena

### Removed
- Configuring OIDC through ansible is removed. To configure OIDC, go to Arena -> Settings ->  Users -> OpenID Configuration
- Variable `zdp_gateway_ha_url` vars.yml and its corresponding usages.

### Renamed 
- The properties related to DME module are renamed.
- In the files `vars.yml` and `main.yml`,
  - `dmx_base_path_for_dme` is renamed to `dme_base_path_for_dme`.
- **Note to Customer:** Please ensure that you set the value of `dme_base_path_for_dme` to whatever was present for `dmx_base_path_for_dme` to avoid any future issues with DME.
- In the file `zdp-dme.yml.j2`:
  - The example value of `keyAlias` for ssl keystore is renamed to `ZdpDmemeta` from `ZdpDmxmeta`.
  - The JHipster mail property's from e-mail id is changed to `ZdpDmemeta@localhost` from `ZdpDmxmeta@localhost`.
  - `dmx_base_path` is renamed to `dme_base_path`. It's default value is taken from property `dme_base_path_for_dme`.
  - In the security settings, `zdp-dmx` property is changed to `zdp-dme`.


### Added
- Added properties `kerberos.keytabs.base.dir` for providing the base location for all keytab files for users

### Renamed 
- The value for the property `kerberos.keytabs.base.dir` is renamed to '/etc/krb5' in the file `vars.yml`.
### Added

- Added a configuration properties `METADATA_NUMBER_OF_FIELDS` for configuring the same property in input.sh during publishing es dump to the new ES.
- Added ability to download zdp_pacakge from s3 bucket when the `zdp_package_location` is Network and zdp_package is not present in `zdp_package_http_location`

### Changed
- Python bin path property is standardize.
  - `PYTHONPATH` property is removed from `zdp-mr.conf` file
  - `python.bin.path` property is added to `zdp-mr.yml` and `zdp-executor.yml` files with `/usr/bin/python` as default value.
  - A new property `python_bin_path` is added to **vars.yml** files for capturing `python.bin.path` property value.

### Added
- Added configurable smtp properties.
  - `mail_smtp_server_host` - mail server host name, default value is localhost
  - `mail_smtp_server_port` - mail server port, default value is 25
  - `mail_smtp_server_user` - mail server user
  - `mail_smtp_server_password` - mail server password
  - `mail_smtp_ssl_enabled` - mail server ssl enabled, default value is false 
  - `mail_smtp_starttls_enabled` - mail server starttls enabled , default value is false
  - `mail_smtp_auth` - mail server auth enabled, default value is false
  - `mail_smtp_timeout` -  mail server timeout, default value is 20000 ms
  - `mail_smtp_connectiontimeout`: timeout to connect mail server, default value is 20000


### Changed
- moved smtp properties from zdp-executor.yml.j2 to registry/application.yml.j2 

- Containerized zdp-ansible
  - use ``` docker build -t zdp-ansible:${ZDP_TAG} -f ./Dockerfile .``` to build an image
- OIDC support is added with support for Okta and Keycloak
### Removed
- Support for spark 1 is removed. Consequently spark 1 related congiguration properties are removed.
  - From now on, `spark_master` will have only one value i.e. `spark2`
  - Spark 1 properties such as `spark1_home`, `spark1_master_url`, `spark1_deploy_mode`, etc. are removed.
### Added
- Support for mysql 8 is added. zdp-ansible now supports both mysql 5 and mysql 8.
  - mysql_version is introduced, expected values are 5.7 and 8.0.
  - Based on mysql_version, database will be configured, by default it's 8.0.
  - If mysql_version is 5.7, configuration is done for mysql 5.7.
  - If mysql_version is 8.0, configuration is done for mysql 8.0.23.
  - In pre-requisite playbook, we check for minimum version. For 5.7, it's 5.7.8 and for 8 it's 8.0.23.
### Added
- Following configurable variables for customisation of dca.properties file for ingestion warden
  -- `monitor_poller_interval_seconds` - Represents the value for the property `monitorPollerIntervalSeconds`
  -- `s3_consistency_retry_initial_interval` - Represents the value for the property `fs.s3.consistency.retry.initial.interval`
- Tasks to help set these values in the dca.properties file under `/etc/zdp-ingestion-warden/agents/bdca`

### Added
- Introduced the following property for zdp-executor.yml
  -- `tokenization.hash.secret` - In tokenization workflow, this parameter is used as a hash secret key to the hashing algorithms. By default this property is disabled.
- Added following configurable variables for zdp-executor service
  -- `vault_sha_tokenization_secret` - stores the value for the hash secret that is to be used in tokeization workflow. Added in vault.yml.
  -- `sha_tokenization_secret` - takes its value from the variable `vault_sha_tokenization_salt` present in vault.yml 

### Added
- Following configurable variables:
    - `client_transport_sniff` - Enable ES host sniffing.

### Added
- Following configurable variable for zdp executor service
  -- `watermark_output_partitioned_entity` - Partition the output entity of watermark action by setting it to true. Default is true.

## [6.1.0]

### Changed
- Moved all properties from default.yml(which are not in vars.yml) to main.yml
- Deleted default.yml

### Added
- Introduced the following property for zdp dme service
  -- `spark.deploy.mode` - spark deploy mode using which sampling job would run
  -- `spark.home.path` - spark home
- Made spark extra opts configurable by adding `spark_extra_opts`, spark will pick value of this variable for setting extra opts.
- Added `lineage_hook_file_location` for configuring lineage output file path.
- Added `spark_job_conf` to configure sampling spark submit job

### Added
- Following configurable variable:
    - `erase_all_data` - removes all the config files, log files when running the uninstall playbook when set to true. Also used to remove existing databases from the DB.
- Adding `erase_all_data` inside default , else all automation will fail [DEVOPS-1121]
   
### Changed
- zdp-uninstall-playbook.yml
    - When removing particular services using tags, add the following `--skip-tags="always"` to the command.
    - Not required to do the above when not using tags or when `erase_all_data` is set to false.

### Changed
- moved `zdp_hdfs_lib_dir` from vars.yml to default.yml with a default value

### Removed
- Removed following property for zdp-dme service
  - `zdp_admin_user_name_for_dme` - username of the zdp admin
  - `zdp_admin_user_password_for_dme` - password of the zdp admin

## [6.0.0]

### Added
- added a default variable `enable_activemq_ha` which sets up activemq HA if multiple activemq nodes are set up.
- Added following configurable variables for zdp-dme service
  - `zdp_admin_user_name_for_dme` - username of the zdp admin
  - `spark_master_url_for_dme` - spark url for dme execution
  - `dmx_base_path_for_dme` - dmx base path for dme execution
  - `spark_url_conf_for_dme` - spark url for starting up of dme service
  - `hadoop_native_lib_for_dme` - hadoop native lib for starting up of dme service

## [5.2.0]

### Added

- Molecule Integrated with on-prem vms
- Molecule Integrated with docker
- Added a variable `is_kerberos_enabled` to be defined by the use to check if kerberos is enabled.
- Added configurable ports at which the ZDP MR, Spark, DME services listen
- Introduced the following variables:
  - `hive_metadata_implementation` - For key hive.metadata.implementation. Possible values are hcatalog, jdbc.
  - `import_zdp_db_backup` - To specify if backup needs to be imported back to mysql.
  - `configure_mysql`- Specify if ansible needs to configure mysql as per zdp-requirements.
  - `zdp_db_backup_location` - Required when import_zdp_db_backup is true.
  - `zdp_db_certs_location` - Required if mysql needs to be connected via ssl.
  - `zdp_start_on_boot` - Added variable to configure if the services needs to start on boot, defaults to false.
  - `nfs_service_name` Added variable for multi-os support for nfs server.
  - `rpcbind_service_name` Added a new variable for nfs-server dependency to restart the rpcbind
- Enabling TLS will also enable https for ActiveMQ Web Console.
- Added support for Specifying url for each rpm if zdp_rpms_location=Network, properties are
  - zdp_registry_url
  - zdp_es_url
  - zdp_gateway_url
  - zdp_activemq_url
  - zdp_logstash_url
  - zdp_kibana_url
  - zdp_lineage_url
  - zdp_ingestion_warden_url
  - zdp_executor_url
  - zdp_hive_url
  - zdp_mr_url
  - zdp_spark_url
  - zdp_dme_url
- Added role zdp-rpm-s3-download - This role downloads rpms from an s3 bucket to target node using signed URLs
- Added property update_zdp_system_config and zdp_system_config_key_value_pairs for updating zdp system config property. 
If sentry is enabled, then system config property HIVE_ACTION_SKIP_ADD_JARS required to be set to true,

### Changed

- Added multi container docker support.
- Verified against ansible-lint rules.
- Added support to configure mysql and add new db user if required
- Added support to configure shared directory if not already present.
- Made the zdp-service's port configurable except for zdp-logstash, zdp-es and zdp-registry. Default ports are found in defaults.yml
All notable changes to this project will be documented in this file.

## [5.0.2.3.9] - 2019-05-06

### Changed

- Fix kibana ssl issue where ssl.enabled: true works but not ssl.enabled: True

## [5.0.2.3.9] - 2019-06-30

### Changed

- Added instructions in README to guide configuring custom ip address and pem files
- Updated zdp-start-playbook.yml to support the status check using ansible_host if configured in hosts.yml inventory

## [released]

## [5.0.2.3.9.1] - 2019-06-10

### Changed

- Added patch 9 and patch 9.1 config changes to defaut.yml
	"#configure gateway io threads
	gateway_undertow_io_threads: 64
	#configure gateway worker threads. Default if not set is 8 * cpu
	gateway_undertow_worker_threads: 512
	#configure No of threads to be used for entity synchronization with globalsearch index 
	metadata_share_es_sync_threads: 4
	#configure No of entities that need to be processed by each thread at a time.
	metadata_share_es_sync_batchsize: 25"
- Added heap dump for gateway when gateway ran out of heap memory. The dump will be in /var/log/zdp-gateway dir.

## [5.0.2.3.9.4] - 2019-07-05

### Changed

- Added patch 3.9.4 config to inventory default.yml
	#configure hikari max pool size spring.datasource.hikari.maxPoolSize
	gateway_spring_datasource_hikari_maxpoolsize: 295
- Updated zdp-gateway.conf to UseG1GC as per patch readme
- Updated zdp-gateway.yml.j2 with patch readme configuration
- Added heap dump for es, executor when gateway ran out of heap memory.
	The dump will be in /var/log/[zdp service] dir.
- Added zdp-es.service.j2 and zdp-gateway.service.j2 to set the `LimitNOFILE`, `LimitNPROC` and `LimitMEMLOCK`
- Updated memory recommendations for zdp-es and zdp-gateway to use in Prod in example inventory.

## [5.0.2.3.10] - 2019-07-09

### Changed

- Added patch 3.10 log4j2.xml config change through roles/executor/templates/log4j2.xml.j2 template.
- Added http.max_content_length for roles/es/templates/elasticsearch.yml.j2 to support backup and restore

## [5.0.2.3.11] - 2019-07-30
### Changed
- Added systemd daemon-reload to zdp-es and zdp-gateway before starting service in zdp-start-playbook.yml in deployments where zdp-es and zdp-gateway are deployed on isolated nodes and no other zpd services are deployed
- Updated example inventory to represent ZDP HA recommendations

## [5.0.2.3.12] - 2019-08-29

### Changed

- Added new propery write_zdp_logs_to_system_logs to default.yml inventory file.
	"Fixed	SID 11087 The zdp-lineage logs are seen on /var/log/messages. GIS violation is created for the issue."
	#configure to write ZDP logs to /var/log/messages. 
	Default is `False` and will not write log messages to `/var/log/messages`
	write_zdp_logs_to_system_logs: False
- Changed zdp services data backup to tar to imporve backup timings.
- Changed recommendation for gateway_undertow_worker_threads and gateway_spring_datasource_hikari_maxpoolsize in inventory/example/group_vars/all/default.yml
	"gateway_undertow_worker_threads: 1000
	gateway_spring_datasource_hikari_maxpoolsize: 1000"

## [5.0.2.3.14] - 2019-09-25
## Changed
- Fixed ansible configuration Bug
	ZDP-2638 While deploying zdp through Ansible in https mode, zdp-logstash is unable to communicate with ES
	Added new property elasticsearch_https to default.yml
- Added support for ZDP services installation on Ubuntu and Debian using Control and Target options
        This is helpful when ZDP cluster microservices are deployed in HDInsight which comes with Ubunt OS for Head Nodes
- Removing web_hcatalog_lib from vars.yml as in ZDP-5.1 it is going to auto-populate. Moving web_hcatalog_lib to default.yml so that if user wants to modify the path. Also removing web_hcatalog_lib associate code from zdp-prerequisites-playbook.yml

## [Unreleased]

### Added
- Support for deb packages. Appropriate package will be installed on the basis of package manager(yum/apt)
- Added following new properties in Vars
    zdp_deb_repo_apt_key_url: Url for apt key
    zdp_deb_repo_url: Url for apt repo
    {Service}_deb_package_name: Deb package names for all services
- Added http URLs for all deb and rpm packages
    RPM: zdp_{service}_rpm_url
    DEB: zdp_{service}_deb_url
- Added hive_inventory_update_source_schema in default under roles/zdp so that molecule gateway validation test can pass

### Changed
- Following properties were changed to make them generic
    zdp_rpms_location => zdp_package_location
    zdp_rpms_location_on_control_server => zdp_package_location_on_control_server
    zdp_rpms_location_on_target_serve => zdp_package_location_on_target_server
- ZDP package location from repo is changed from 'Yum' to 'Repo'
    Yum repo: still defined by zdp_yum_repository_name
    Apt repo: Url defined by zdp_deb_repo_url
- Changed s3 download role
    Changed the name from zdp-rpms-s3-download to zdp-pkgs-s3-download
    Added task for uploading deb builds to sandbox in a new file upload-deb-to-sandbox.yml
    Added a generic task file upload-pkgs-to-sandbox.yml to upload packages based on supported package manager(apt or rpm)
- Updated the API from  text/plain  to application/json [DEVOPS-929]

### Removed
- Removed all zdp_{service}_url as specific url for rpm and deb packages are added(See added section). 

### Added
- Following configurable variables:
    - `elasticsearch_client_autorecovery_enabled` - Enables ES client recovery when all ES nodes gets disconnected, applicable only when ES is accessed using DNS.
    - `elasticsearch_client_autorecovery_delay` - Delay period in milliseconds after which ES client is scanned for node disconnection.

### Added
- Added following spring-boot properties for rest-client auto-configuration:
    - `spring.elasticsearch.rest.uris` - Comma-separated list of the Elasticsearch instances to use,
      for example:[http://localhost:19200].
    - `spring.elasticsearch.rest.connection-timeout` - Connection Timeout
    - `spring.elasticsearch.rest.read-timeout` - Read Timeout

### Added
- Added property `arena.gateway.url` in the 'zdp-executor.yml'.This property will set Gateway/HA URL to be used by workflow actions.




