 ZDP Packages S3 Download
=========
 This role downloads ZDP RPMs from s3 bucket and places on the target node.

 1. `roles/zdp-pkgs-s3-download/tasks/upload-pkgs-to-sandbox.yml` - copies packages files from s3 into the nodes where ZDP should be installed. This could be put in the ZDP installer but the same S3 bucket structure may not be followed by non-Zaloni developers. Also other use cases may require that packages be installed in other ways.

 Variables:-
 1. zdp_rpms_s3_bucket - Name of the s3 bucket, where zdp rpms present,
    example zaloni-zdp-rpm/release/5.1.0, here 'zaloni-zdp-rpm' is bucket name and 'release/5.1.0' folder inside it
 2. zdp_package_location_on_target_server - location on the target node where rpms needs to be place after download
 3. zdp_debs_s3_bucket - Name of the s3 bucket, where zdp debs are present,
    example zaloni-zdp-deb/release/5.1.0, here 'zaloni-zdp-deb' is bucket name and 'release/5.1.0' folder inside it
 