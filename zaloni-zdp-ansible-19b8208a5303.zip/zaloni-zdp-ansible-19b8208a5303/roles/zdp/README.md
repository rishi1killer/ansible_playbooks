Roles
=========

Roles - ZDP, Mysql, Node

_ZDP-role_ is created in alignment of the zdp-app. This role contains all the tasks
corresponding to the services in zdp-app. It is also integrated with Molecule framework
which enables the developers to create test cases related to the various operations
of this role.

This role enables the user to setup, configure, install, and start, stop, uninstall
the zdp-app. Various playbooks are provided which does the respective operations.

_Mysql-role_ contains tasks related to database cleanup, setup, and other managements
as per zdp.

_NodeJs-role_ contains tasks specific to nodejs version checks used in zdp. 


Requirements
------------

In-order to run this zdp role there are some pre-requisites which needs to be setup.
Java 8 and  msyql 5+ is required before the playbooks are run.

Ansible 2.7+ and Python 2.7+ are mandatory.

Latest pip version should be installed.

Molecule is required for testing the test scenarios and can be installed as:

```bash
pip install --user molecule
```

A few playbooks are provided which would automatically take care of the pre-requisite checks
and setup. For instance,

* `zdp-prerequisites-install-paybook.yml` - This playbook creates service owners in all
the hosts and install the supported version of NodeJS.
* `zdp-prerequisites-playbook.yml` - This checks some necessary checks like MySQL version,
java version, hadoop classpath, hive-lib path and other variables provided as the variables


Role Variables
--------------
The zdp roles uses some pre-defined and user-defined variables to function various tasks mentioned.
These variables are defined in a vars folder under /inventory directory. However, it is recommended
that the user creates his own variables referring to the existing /example under inventory.

An example of the directory structure is provided for reference. In the custom inventory it is 
required to have a hosts.yml file which defines all the hosts where each services would be installed.
    
    - inventory
        example
           - group_vars
                - all
                    - default.yml
                    - vars.yml
                    - vault.yml
           - hosts.yml 
        user1_inventory
           - group_vars
                - all
                    - default.yml
                    - vars.yml
                    - vault.yml
           - hosts.yml 



Dependencies
------------

Zdp role mainly depends on two other roles viz. _mysql_ and _node_.
Molecule is required to test various scenarios and custom test cases written for the zdp role. 
Few scenarios are created for reference. It has its respective playbook.yml, which is the starting
point for executing the scenarios.


Run Test Cases
--------------

A tool called Molecule has been integrated to run e2e infra tests. The molecule directory resides inside
the role `zdp`. Molecule tests are designed to test an individual role. Inside the molecule directory, there
are many scenarios created. Basic commands used are:

_molecule init role --role-name <role-name>_

-- Initialize a new role. Here <role-name> is zdp

`molecule init scenario <scenario-name> --role-name <role-name>`

Eg: `cd zdp-ansible/roles/zdp; molecule init scenario test-gen-certs --role-name zdp`

-- Initialize a new scenario under a specific role

The directory structure looks like:

```
    - zdp
        molecule
            default
            gateway
            registry
            zdp
```

These scenarios serve a special purpose. As the name suggest gateway tests if zdp-gateway is running fine,
registry tests if zdp-registry and all its dependencies are being installed properly and registry is up and 
running, whereas, zdp tests if all the prerequisites, services are installed, and then started and are running
appropriately.

Each scenario again has its own definition. The directory structure is:
        
        - gateway
            - install
                - es_playbook.yml
                - regsitry_playbook.yml
            - start 
                - registry_playbook.yml
                - gateway_playbook.yml
            - vars
                - all
                    - default.yml
                    - vars.yml
                    - vault.yml
            - tests
                - tes_gateway.py
            - Dockerfile.j2
            - molecule.yml
            - gateway_hosts.yml
            - playbook.yml
        
Definition of each directories and files:

    install/ - This directory contains the installer palybooks of the required dependent services.

    start/ - This directory contains the start playbooks of the required and dependent services

    vars/ - This directory has the user-defined variables, default and sensitive data.

    tests/ - It ontains the infra test cases of the respective scenarios

    Dockerfile.j2 - This is the default initialization of the docker script for the driver, molecule runs

    molecule.yml - This file contains the definition of the scenarios and configuration used.

    gateway_hosts.yml - This contains the hosts information where the scenario:gateway would use.

    playbook.yml - This is the entry point for the scenario.


Inorder to run the test cases for each scenario, the following command can be used:
 
    _cd <role-under-test-directory>_
 
     _molecule test -s <scenario-name>_
 
 For Example, 
 If we want to test the role _zdp_ and the scenario _gateway_, we would use:
 
    _cd <ansible-projectPath> roles/zdp_
 
    _molecule test -s gateway_

For more information on molecule see: 

    _molecule --help_

For override some scenarios used in _test_ command use the following:


    _cd <ansible-projectPath> roles/zdp_


    _molecule create -s gateway_

    _molecule converge -s gateway_

    _molecule verify -s gateway_

Also, we can define custom scenario in the molecule.yml for each scenario. 
To check full list of operations performed in each command see here:

https://molecule.readthedocs.io/en/stable/configuration.html#root-scenario



Example Playbook
----------------

The zdp role can be executed by directly using the ansible command.

    ansible-playbook zdp-main-playbook.yml -i /inventory/example
 
 The above command runs the main playbook which checks the pre-requisites, installs the app and starts
 various services present. Other playbooks can also be used as per requirement. This command is fired
 inside the parent project directory /zdp-ansible.
 
 
 Using molecule, we run the test scenarios as: 
 
    molecule test -s zdp

The molecule.yml is expected to be configured properly before running any scenario.
a particular scenario can be specified using the -s args shown above.
The test cases are written in roles/zdp/molecule/<scenario-name>/tests directory.

Necessary Commands
----------------

1. Initialize a new role using molecule: molecule init role -r <role-name>
2. Initialize a new scenario in an existing role: molecule init scenario <scenario-name> -r <role-name>
3. For help: molecule init --help | molecule init scenario --help
