import os

import testinfra.utils.ansible_runner

testinfra_hosts = testinfra.utils.ansible_runner.AnsibleRunner(
    os.environ['MOLECULE_INVENTORY_FILE']).get_hosts('registry')


def test_hosts_file(host):
    f = host.file('/etc/hosts')

    assert f.exists
    assert f.user == 'root'
    assert f.group == 'root'


def test_is_registry_installed(host):
    package_docker= host.package("zdp-registry")
    assert package_docker.is_installed


def test_is_es_installed(host):
    package_es= host.package("zdp-es")
    assert package_es.is_installed


def test_is_es_up(host):
    es= host.service("zdp-es")
    assert es.is_running


def test_is_registry_up(host):
    zdp_registry= host.service("zdp-registry")
    assert zdp_registry.is_running

