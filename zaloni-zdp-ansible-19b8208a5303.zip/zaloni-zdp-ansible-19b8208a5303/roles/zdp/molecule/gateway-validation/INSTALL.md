# Gateway Validation Molecule Scenario

This folder describes a test that validates whether ZDP Gateway and its
 prerequisite services start up correctly. If effect, it is validating not just
 the Ansible installer, but the ZDP binaries as well.

## Prerequisite software

To run this test you will need:

* Python and virtualenv
* Docker
* Ansible
* Molecule

Now set up the environment:

First set up a python virtual environment (you can delete it later):

```bash
  virtualenv ~/zdp-molecule-test
  source ~/zdp-molecule-test/bin/activate
```

Now install all the prerequisites (ansible, molecule, etc)

```bash
  cd zdp-ansible/roles/zdp/
  pip install -r molecule/moleculeRequirements.txt
```
  
Set up the test environment

```bash
molecule converge -s gateway-validation
molecule destroy -s gateway-validation
```
