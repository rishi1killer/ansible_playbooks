import os

import testinfra.utils.ansible_runner

testinfra_hosts = testinfra.utils.ansible_runner.AnsibleRunner(
    os.environ['MOLECULE_INVENTORY_FILE']).get_hosts('gateway')


def test_hosts_file(host):
    f = host.file('/etc/hosts')

    assert f.exists
    assert f.user == 'zaloni'
    assert f.group == 'domain-users'


def test_is_gateway_installed(host):
    package_docker= host.package("zdp-gateway")
    assert package_docker.is_installed


def test_is_gateway_up(host):
    zdp_gateway= host.service('zdp-gateway')
    assert zdp_gateway.is_running



